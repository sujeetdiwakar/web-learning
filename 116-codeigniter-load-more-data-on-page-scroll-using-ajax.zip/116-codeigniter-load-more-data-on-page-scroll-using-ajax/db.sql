--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `post_title` varchar(250) NOT NULL,
  `post_description` text NOT NULL,
  `author` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `post_title`, `post_description`, `author`) VALUES
(1, 'Post 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.', 'Test'),
(2, 'Post 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.', 'Testing'),
(3, 'Post 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.\r\n', 'Test'),
(4, 'Post 4', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium ex risus, eget fermentum purus rhoncus ac. Sed feugiat laoreet ligula sit amet finibus. Sed a elit interdum, auctor nibh finibus, scelerisque ipsum. Duis pharetra enim sit amet ligula volutpat tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam venenatis dui enim, vel sollicitudin ante congue ac. Duis a arcu metus. Etiam mollis bibendum enim et tincidunt. Nullam ac ante non nulla viverra feugiat eget a velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec non erat non diam dignissim consectetur. Aliquam egestas consectetur tortor vitae malesuada. Maecenas sit amet lacus mollis, rhoncus magna in, tristique purus. Vestibulum eleifend eros leo, vel luctus felis venenatis a. Morbi mattis tellus ut rhoncus euismod.', 'Testing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;